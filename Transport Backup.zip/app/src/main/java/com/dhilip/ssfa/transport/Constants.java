package com.dhilip.ssfa.transport;

/**
 * Created by Dhilip on 6/11/2016.
 */
public class Constants
{
    public static String DATEFORMAT = "yyyy-MM-dd HH:mm:ss";
    public static String SECONDARY_DATEFORMAT = "dd MMM HH:mm";

    public static String SELECTED_DATETIME = "SelectedDateTime";
    public static String ISDEPARTURE = "IsDeparture";
}
